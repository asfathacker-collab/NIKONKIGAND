#include "NIKONOP/Tools.h" 
#include "NIKONOP/Logger.h"
#include "NIKONOP/oxorany.h"
#include "NIKONOP/obfuscate.h"
#include "NIKONOP/Utils.h"
#include "NIKONOP/KittyMemory/MemoryPatch.h"
#include "Hook/shadowhook.h"
#include "GlossHook/Gloss.h"
#include "NIKONOP/Dobby/dobby.h"
#include "NIKONOP/Macros.h"
#include <list>
#include <vector>
#include <string>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <stddef.h>
#include <jni.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <unordered_map>
#include <chrono> 
#include <fcntl.h>
#include <sys/stat.h>
#include <cstddef>
#include <semaphore.h>
#include <stdint.h>
#include <sstream>
#include <stdarg.h>
#include <stdio.h>
#include <curl/curl.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <unwind.h>
#include <android/log.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>

#define targetLibName OBFUSCATE("libanogs.so")
#define targetLibName OBFUSCATE("libUE4.so")
#define targetLibName OBFUSCATE("libhdmpve.so")
#define targetLibName OBFUSCATE("libanort.so")
#define targetLibName OBFUSCATE("libTBlueData.so")
#define targetLibName OBFUSCATE("libCrashKit.so")

auto ret = reinterpret_cast<uintptr_t>(__builtin_return_address(0));
using namespace std;

#define ARM64_SYSREG(reg0, reg1, reg2, reg3, op) (((reg0) & 0x1F) | (((reg1) & 0x1F) << 5) | (((reg2) & 0x7) << 10) | (((reg3) & 0xF) << 16) | (((op) & 0x7) << 20))

#ifdef __aarch64__
uint64_t _ReadStatusReg(uint64_t reg) {
    return 0;
}

#endif

char *Offset;

#define __int8 char
#define __int16 short
#define __int32 int
#define __int64 long long
#define _BYTE  uint8_t
#define _WORD  uint16_t
#define _DWORD uint32_t
#define _QWORD uint64_t
#define _BYTE  uint8_t
#define _WORD  uint16_t
#define _DWORD uint32_t
#define _QWORD uint64_t
#define _OWORD uint64_t
#define _BOOL8 uint64_t
#define j_j__free
#define log_suspicious_activity

#define HIWORD
#define __strncpy_chk
#define __memcpy_chk
#define __strncpy_chk2
#define __fgets_chk
#define __errno
#define qmemcpy

#define byte_4
#define _ReadStatusReg
#define BYTE5
#define BYTE4
#define HIBYTE
#define BYTE6
#define IsMemoryReadable
#define BYTE1
#define BYTE3
char *dword_57F060;
char *qword_1C9D48;
char *qword_57CE08;
char *stru_57CE10;
char *dword_579D28;
uint32_t dword_5755A4;

#define BYTE2
#define ARM64_SYSREG
#define _WriteStatusReg
#define LOBYTE
#define BYTE

DWORD TBlueBase = 0;
DWORD AntBase = 0;
DWORD BufferBase = 0;
DWORD HdmpveBase = 0;
DWORD roosterBase = 0;
DWORD roosterSize = 0;
DWORD roosterAlloc = 0;

DWORD EGLBase = 0;
DWORD EGLSize = 0;
DWORD EGLAlloc = 0;

DWORD libcBase = 0;
DWORD libcSize = 0;
DWORD libcAlloc = 0;

DWORD libUE4Base = 0;
DWORD UE4Base = 0;
DWORD libanogsBase = 0;
DWORD libanortBase = 0;
DWORD libanogsAlloc = 0;
DWORD libUE4Alloc = 0;
DWORD libTaito = 0;

DWORD NewBase = 0;

unsigned int libanogsSize  = 0;
unsigned int libUE4Size  = 0;

extern uintptr_t UE4;
uintptr_t UE5;

#include <stddef.h>
#include <stdio.h>


// ADD SKIN ///

size_t NIKONSKIN(const char *s) {
 static const std::unordered_map<std::string, std::string> replacements = {
		{"403006", "1405870"},//DRAGONFLAME BERSERKER SET
        {"1406748", "1407512"},//DRAVION X-SUIT (7-STAR)
        {"1405269","1407695"},// WINTER HIGHNESS SET
        {"404151", "1407049"}, // BAPE X PUBGM CAMO SHORTS
        {"1405884", "1406573"}, // WUKONG PRIME
        {"403003", "1407440"}, // TEMPERANCE'S VIRTUE SET
        {"403020", "1407470"}, // GOLDEN PHARAOH DIVINE SET
        {"403032", "1407276"}, // PATCHMETAL BUNNY SET (LV. 3)
        {"403224", "1407387"}, // SOUL-EATER UNDERWORLD KING
        {"403160", "1407459"}, // ZERO COMBAT SUIT
        {"403002", "1400687"}, // PHANTOM NIGHT SHINIGAMI SET
        {"403198", "1400687"}, // HALLOWEEN MUMMY   
        {"1405113", "1406939"},//GOKU
        {"1405548", "1400687"}, //MUMMY SET
        {"1405884", "1405132"}, //FOREST ELF SET     
       {"1405388", "1407758"}, //new ultimet 
        {"1405586", "1405870"},    // BLOOD RAVEN
        {"1405647", "1406971"},    //  Marmoris X-Suit 
        {"1405196", "1407841"},   // new hani bagger 
        {"1405807", "1405983"},    // Poseidon X-Suit
        {"1405548", "1406469"},   //Golden Pharaoh X-Suit (7-Star) | 
        {"1405113", "1407512"},   // Arcane Jester X-Suit (6-Star)
        {"403041", "1407142"},    // Silvanus X-Suit (7-Star)
        {"403224","1406727"}, //pri
        {"403006", "1406152"},    // Avalanche X-Suit
        {"1402154", "1405934"},   // Godzilla Set
        {"1402155", "1410826"},    // Mask
        {"403042", "1405092"},   // Vampyra Set
        {"403033", "1407512"},//Dravion X-Suit (7-Star)
        {"403211","1407695"},// Winter Highness Set   
        {"403163", "1406573"}, // Wukong Prime
        {"403042", "1407695"}, // Macabre Valentine Set
        {"403006", "1405870"},//DRAGONFLAME BERSERKER SET
        {"1406748", "1407512"},//DRAVION X-SUIT (7-STAR)
        {"1405269","1407695"},// WINTER HIGHNESS SET
        {"404151", "1407049"}, // BAPE X PUBGM CAMO SHORTS
        {"1405884", "1406573"}, // WUKONG PRIME
        {"1405113", "1407329"}, // THE REAPER'S END SET
        {"1405548", "1407392"}, // GALADRIA X-SUIT (7-STAR)
        {"403003", "1407440"}, // TEMPERANCE'S VIRTUE SET
        {"403020", "1407470"}, // GOLDEN PHARAOH DIVINE SET
        {"403032", "1407276"}, // PATCHMETAL BUNNY SET (LV. 3)
        {"403224", "1407387"}, // SOUL-EATER UNDERWORLD KING
        {"403160", "1407459"}, // ZERO COMBAT SUIT
        {"403002", "1400687"}, // PHANTOM NIGHT SHINIGAMI SET
        {"403195", "1407267"}, // Super Saiyan Blue Son Goku Character Set"}, 
        {"403177", "1407268"}, // Super Saiyan Blue Son Goku (Damaged) Character Set
        {"403178", "1407269"}, // Super Saiyan Blue Vegeta Character Set
        {"403160", "1407270"}, // Super Saiyan Blue Vegeta (Damaged) Character Set
        {"403161", "1406241"}, // Megumi Fushiguro Cosplay Set
        {"1400781", "1406244"}, // Satoru Gojo Serious Mode Cosplay Set
        {"1400470", "1406398"}, // Flamewraith Se
        {"1400470", "1407392"}, // Flamewraith Set
        {"1400415", "1407265"}, // Super Saiyan Vegito Character Set
        {"1407144", "1407387"}, // Feral Ravager Set
        {"403007", "1407425"}, // The Reaper's End Set
        {"403007", "1407758"}, // The Reaper's End Set
        {"1405211", "1407266"}, // Super Saiyan Blue Vegito Character Set
        {"403153", "1407264"}, // Vegito Character Set
        {"1405211", "1407758"}, // NEW 
        {"1405487", "1407276"}, // The Lover's Grace Set 
        {"1405151", "1410668"}, // Inferno Fiend Set
        {"1405151", "1407277"}, // Inferno Fiend Set
        {"1400295", "1406891"}, // Psychophage Set
        {"1405547", "1407558"}, // The Sun's Ascendance Set
        {"1400237", "1407559"}, // The Moon's Luminance Set
        {"1405715", "1407572"}, // Bloodbane Vesper Set
        {"1405211", "1407275"}, // Temperance's Virtue Set
        {"403170", "1407276"}, // The Lover's Grace Set
        {"403154", "1407271"}, // Bulma Character Set
        {"403039", "1406937"}, // Super Saiyan Son Goku Character Set
        {"403040", "1406938"}, // Frieza Character Set
        {"403041", "1406947"}, // Vegeta Character Set
        {"403042", "1406140"}, // Jinx Suit
        {"403043", "1406399"}, // Majestic Cavalry Set
        {"403194", "1406977"}, // Wrathful Neptune Set
        {"10100400", "1101004209"}, // M416
        {"10100100", "1101001265"}, // AKM
        {"10100300", "1101003219"}, // SCAR-L
        {"10100500", "1101005098"}, // GROZA
        {"10100600", "1101006075"}, // AUG
        {"10100200", "1101002056"}, // M16A4
        {"10100800", "1101008154"}, // M762
        {"10110200", "1101102025"}, // ACE32
        {"10200200", "1102002424"}, // UMP45
        {"10200100", "1102001120"}, // UZI
        {"10200300", "1102003100"}, // VECTOR
        {"10200500", "1102005064"}, // BIZON
        {"10200400", "1102004018"}, // TOMMY
        {"10210500", "1102105012"}, // P90
        {"10300300", "1103003079"}, // AWM
        {"10300100", "1103001202"}, // Kar98K
        {"10300200", "1103002030"}, // M24
        {"10300700", "1103007020"}, // MK14
        {"10500200", "1105002091"}, // DP-28
        {"10500100", "1105001069"}, // M249
        {"10501000", "1105010019"}, // MG3
        {"10400400", "1104004035"}, // DBS
        {"10400300", "1104003037"}, // S12K
        {"10800400", "1108004356"}, // PAN
        {"10101200", "1101012033"}, // HONEY BADGER
        {"10100900", "1101009012"}, // FAMAS
        {"10301200", "1103012031"}, // AMR
        {"10300500", "1103005037"}, // MINI14
        {"10300400", "1103004058"}, // SKS
        {"10300900", "1103009028"}, // SLR
        {"10410100", "1104101001"},  // M1014
        {"502001","1502001014"}, // helmet
        {"502002","1502002014"}, // helmet
        {"502003","1502003014"}, // helmet   
        {"501001", "1501003688"}, // Backpack (Lv. 1) 
        {"501002", "1501003688"}, // Backpack (Lv. 2) 
        {"501003", "1501003688"}, // Backpack (Lv. 3) 
   // ------------ CONQUEROR FRAME ------------ //
        {"2001001", "2002941"}, // S22 CONQUEROR FRAME		
		// ------------ EMOTES ------------ //
        {"2200101", "12201301"}, // DARK ASSASSIN
        {"2200301", "2490005"}, // DEATH'S TOUCH
        {"2200201", "12220028"}, // THANK YOU     
        {"703001", "4151105"},// | Doombound Express Glider |  🔅       
          {"1961001", "1961062"}, // Porsche 918 Spyder (Aquastream) 
		{"1961002", "1961062"},
		{"1961003", "1961062"},
		{"1961004", "1961062"},
		{"1961005", "1961062"},
		{"1961006", "1961062"},
        // _BUGGY MACLAREN ____//
        {"1907001","1907054"},//BUGGY MCLAREN FORMULA 1 TEAM RACE CAR (DIGITAL)
        {"1907002","1907054"},//BUGGY MCLAREN FORMULA 1 TEAM RACE CAR (DIGITAL)
        {"1907003","1907054 "},//BUGGY MCLAREN FORMULA 1 TEAM RACE CAR (DIGITAL)
        {"1907004","1907054"},//BUGGY MCLAREN FORMULA 1 TEAM RACE CAR (DIGITAL)
        {"1907005","1907054"},//BUGGY MCLAREN FORMULA 1 TEAM RACE CAR (DIGITAL)
        {"1907006","1907054"},//BUGGY MCLAREN FORMULA 1 TEAM RACE CAR (DIGITAL)      
   	    {"1908002","1908108"},//UAZ
        {"1903001","1903218"},//Porsche Panamera Turbo S (Sapphire Blue) |- 
        {"1903002","1903218"},//Porsche Panamera Turbo S (Sapphire Blue) | - 
        {"1903003","1903212"},//Bee Sting Dacia- 
        {"1903004","1903212"},//Bee Sting Dacia- 
       //MIX VEHICLE SKIN//      
       {"1953001","1953012"},//SEA WRATH MONSTER TRUCK (LV. 4)
       {"1953002","1953012"},//SEA WRATH MONSTER TRUCK (LV. 4)
       {"1908001","1908108"},//Porsche Cayenne Turbo GT (Hot Streak) |
       {"1915001","1915008"},//MIRADO BENTLEY CONTINENTAL GTC MULLINER (HOLOCRYSTAL)
       {"1915002","1915008"},//MIRADO BENTLEY CONTINENTAL GTC MULLINER (HOLOCRYSTAL)
       {"1915003","1915018"},//Galvatron Convertible | 
       {"1915004","1915018"},//Galvatron Convertible | 
       {"1914001","1915008"},//MIRADO BENTLEY CONTINENTAL GTC MULLINER (HOLOCRYSTAL)
       {"1914002","1915008"},//MIRADO BENTLEY CONTINENTAL GTC MULLINER (HOLOCRYSTAL)
       {"1914003","1915018"},//Galvatron Convertible | 
       {"1914004","1915018"},//Galvatron Convertible | 
       {"1916001","1916006"},//RONY    TESLA CYBERTRUCK (BLACK-QUARTZ)
       {"1916002","1916006"},//RONY    TESLA CYBERTRUCK (BLACK-QUARTZ)
       {"1916003","1916006"},//RONY    TESLA CYBERTRUCK (BLACK-QUARTZ)
       {"1532907","1901089"},//MOTORCYCLE COSMIC JUMP MOTORCYCLE (LV. 4) 
     };
 auto it = replacements.find(s);
 if (it != replacements.end()) {
 strcpy((char *)s, it->second.c_str());
 }
 return strlen(s);
}

__int64 sub_29BF24()
{
  return 0LL;
}

__int64 __fastcall sub_36A5B8(_DWORD *a1, _QWORD *a2)
{
  int v9;
  const void *v6;
  void *v7;
  __int64 v8;
  size_t v15;
  char v14;

  v9 = (*(__int64 (__fastcall **)(_DWORD *))(*(_QWORD *)a1 + 88LL))(a1);

  if ( v9 >= (*(int (__fastcall **)(_QWORD *))(*a2 + 96LL))(a2) )
  {
    v8 = (*(__int64 (__fastcall **)(_DWORD *))(*(_QWORD *)a1 + 48LL))(a1);
    v7 = (void *)(v8 + (*(int (__fastcall **)(_DWORD *))(*(_QWORD *)a1 + 96LL))(a1));

    v6 = (const void *)(*(__int64 (__fastcall **)(_QWORD *))(*a2 + 48LL))(a2);
    v15 = (*(__int64 (__fastcall **)(_QWORD *))(*a2 + 96LL))(a2);

    memcpy(v7, v6, v15);

    a1[20] += (*(__int64 (__fastcall **)(_QWORD *))(*a2 + 56LL))(a2);
    a1[19] += (*(__int64 (__fastcall **)(_QWORD *))(*a2 + 96LL))(a2);

    (*(void (__fastcall **)(_QWORD *))(*a2 + 128LL))(a2);

    v14 = 1;
  }
  else
  {
    v14 = 0;
  }

  return v14 & 1;
}

__int64 sub_3A4CCC()
{
  return 0LL;
}

__int64 __fastcall sub_4726E0(_QWORD *a1, __int64 *a2)
{
    LOGI("All FIX CALLED A1 : %lld", a1);
   // print_backtrace("hsub_4726E0");

    if (!a1 || !a2)
        return 0;

    // use only real fields from this function
    if (*reinterpret_cast<uint64_t*>(a1 + 69 * 8) != 0 ||
        *reinterpret_cast<uint64_t*>(a1 + 72 * 8) != 0)
    {
        *reinterpret_cast<uint64_t*>(a1 + 69 * 8) = 0;
        *reinterpret_cast<uint64_t*>(a1 + 72 * 8) = 0;

        memset((void*)(a1 + 82 * 8), 0, 0x40);

        pthread_mutex_t* mutex = reinterpret_cast<pthread_mutex_t*>(a1 + 356);
        if (mutex) {
            pthread_mutex_lock(mutex);
            pthread_mutex_unlock(mutex);
        }

        return 1LL;
    }}

__int64 (*osub_4D47D8)(__int64, __int64, int, char);

__int64 hsub_4D47D8(__int64 a1, __int64 a2, int a3, char a4)
{
    switch (a3)
    {
        case 110100:
        case 110101:
        case 110102:
        case 40004:
            return 0; 
    }

    return osub_4D47D8 ? osub_4D47D8(a1,a2,a3,a4) : 0;
}


__int64 __fastcall sub_20FFF8(__int64 a1, char *a2, __int64 a3, unsigned int a4, char a5)
{
    _BYTE v26[8]; 
    int v27;
    __int64 v28 = 0LL;
    if ( !a2 || !a3 )
    return 0xFFFFFFFFLL;
    return 0LL; 
}

__int64 __fastcall (*osub_2234B0)(__int64 a1);
__int64 __fastcall hsub_2234B0(__int64 a1)
{
    if (!*(_BYTE *)(a1 + 0x0A) && *(_BYTE *)(a1 + 0x45)) {
        return 0;
        }
    return 0;
}
static __int64 (*orig_4D1DD0)(__int64, __int64, unsigned __int64) = nullptr;

__int64 __fastcall sub_4D1DD0(__int64 a1, __int64 a2, unsigned __int64 a3)
{
    if (a3 <= 0xFF78 && a3 > 100)
        return 0LL;                 
    return orig_4D1DD0(a1, a2, a3);
}



void *ANOGS_THREAD(void *) {
auto ANOGS = Tools::GetBaseAddress("libanogs.so");
while (!ANOGS) {
ANOGS = Tools::GetBaseAddress("libanogs.so");
sleep(1);
}
LOGI(oxorany("BYPASS HAS BEEN ACTIVATED"));
do {
sleep(1);
} while (!isLibraryLoaded("libanogs.so"));
#if defined(__aarch64__)
HOOK_LIB_NO_ORIG("libanogs.so", "0x4726E0",sub_4726E0);//PTHREAD MITEX
HOOK_LIB_NO_ORIG("libanogs.so","0x29BF24",sub_29BF24);//DEVICE-VALIDATION
HOOK_LIB_NO_ORIG("libanogs.so","0x36A5B8",sub_36A5B8);//FLAG-DELAY 1
HOOK_LIB_NO_ORIG("libanogs.so","0x3A4CCC",sub_3A4CCC);//FLAG-DELAY 2
PATCH_LIB("libanogs.so","0x223FE8","00 00 80 D2 C0 03 5F D6"); // FLAG DELAY 3
PATCH_LIB("libanogs.so","0x4D8470","00 00 80 D2 C0 03 5F D6"); // FLAG DELAY 4
PATCH_LIB("libanogs.so","0x23607C","00 00 80 D2 C0 03 5F D6"); // AUTO REPORT BLOCK IN GAME
PATCH_LIB("libanogs.so","0x37FD78","00 00 80 D2 C0 03 5F D6"); // DAY VIOLATION REGULATION
PATCH_LIB("libanogs.so","0x36A5B8","00 00 80 D2 C0 03 5F D6"); // DAY VIOLATION
PATCH_LIB("libanogs.so","0x431800","00 00 80 D2 C0 03 5F D6"); // DAY VIOLATION
PATCH_LIB("libanogs.so","0x3A564C","00 00 80 D2 C0 03 5F D6"); // VIOLATION FIXER
PATCH_LIB("libanogs.so","0x1ECD44","00 00 80 D2 C0 03 5F D6"); //   REPORT BLOCK
PATCH_LIB("libanogs.so","0x39F56C","00 00 80 D2 C0 03 5F D6"); // EARLY-CALLER
PATCH_LIB("libanogs.so","0x371418","00 00 80 D2 C0 03 5F D6"); //(CRC INTEGRITY CHK)
PATCH_LIB("libanogs.so","0x4B03BC","00 00 80 D2 C0 03 5F D6"); // @NIKON_MOD
PATCH_LIB("libanogs.so","0x505A44","00 00 80 D2 C0 03 5F D6"); // @NIKON_MOD
PATCH_LIB("libanogs.so","0x50C1F8","00 00 80 D2 C0 03 5F D6"); // @NIKON_MOD
PATCH_LIB("libanogs.so","0x5026EC","C0 03 5F D6"); //  MEMORY MASTER OFFLINE
PATCH_LIB("libanogs.so","0x213360","C0 03 5F D6"); //   CRESH FIXER 

/////////    EXTRA  SAFETY     /////////
HOOK_LIB_NO_ORIG("libanogs.so","0x20FFF8",sub_20FFF8);//FLAG HELPER SPECIAL BT
HOOK_LIB("libanogs.so","0x4D47D8", hsub_4D47D8, osub_4D47D8);//REPORT BAN FIX
HOOK_LIB("libanogs.so", "0x4D1DD0", sub_4D1DD0, orig_4D1DD0); // FIX REPORT BAN
HOOK_LIB("libanogs.so", "0x2234B0", hsub_2234B0, osub_2234B0);//FLAG-DELAY 5
PATCH_LIB("libanogs.so","0x2DF104","00 00 80 D2 C0 03 5F D6"); // FLAG-DISABLE 6
PATCH_LIB("libanogs.so","0x330494","00 00 80 D2 C0 03 5F D6"); // CRC CALCULATION
PATCH_LIB("libanogs.so","0x338680","00 00 80 D2 C0 03 5F D6");// SEGMENT CHECK
PATCH_LIB("libanogs.so","0x4C7FE4","00 00 80 D2 C0 03 5F D6");//flag helper 
PATCH_LIB("libanogs.so","0x260B14","00 00 80 D2 C0 03 5F D6");// flag helper 
PATCH_LIB("libanogs.so","0x268174","C0 03 5F D6");// 3 RD PARTY FIX 
PATCH_LIB("libanogs.so","0x139710","C0 03 5F D6");// 10 MIN FIX
PATCH_LIB("libanogs.so","0x21B030","C0 03 5F D6");// 10 MIN FIX

PATCH_LIB("libanogs.so","0x4C7FE4","00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libanogs.so","0x260B14","00 00 80 D2 C0 03 5F D6");
#endif
return NULL;
}


__int64 DAMAGEFIX()
{
  return 0LL;
}

void *UE4_THREAD(void *) {

    LOGI(OBFUSCATE("LOAD BY @NIKON_OWNER"));
        do {
              sleep(1);
   } while (!isLibraryLoaded("libUE4.so"));
// ===============================

HOOK_LIB_NO_ORIG("libUE4.so","0xc25df70", NIKONSKIN);
HOOK_LIB_NO_ORIG("libUE4.so", "0x790AC40", DAMAGEFIX);
PATCH_LIB("libUE4.so","0x6152F70","00 00 80 D2 C0 03 5F D6");// TERMINATION FIX v1
MemoryPatch::createWithHex("libUE4.so", 0x67866E4, "1F 20 03 D5").Modify();
MemoryPatch::createWithHex("libUE4.so", 0x5952F70, "00 00 80 D2 C0 03 5F D6").Modify();

///////////    FLAG DELAY UE4 SIDE     ///////////

PATCH_LIB("libUE4.so","0x5EB74BC","00 00 80 D2 C0 03 5F D6");  //Weapon Client
PATCH_LIB("libUE4.so", "0x5C9F970", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libUE4.so", "0x72AD024", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libUE4.so", "0x999DC24", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libUE4.so", "0x667DFC4", "00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libUE4.so", "0x7C486BC", "00 00 80 D2 C0 03 5F D6");

//    LOGI(oxorany("Done"));
return NULL;
}

__int64 __fastcall (*osub_9AD94)(unsigned int *a1, _QWORD *a2);
__int64 __fastcall hsub_9AD94(unsigned int *a1, _QWORD *a2)
{
    if (a1 && a2)
    {
        __int16 v3 = *((_WORD *)a1 + 11);

        v3 &= ~(0x200 | 0x40 | 0x80);
  
        v3 |= 0x20; 

        *((_WORD *)a1 + 11) = v3;

        if (v3 & 0x20)
            *a1 = 1;//Taito
    }

    return 0LL; 
}

__int64 sub_2BFF7C()
{
  return 0LL;
}

__int64 sub_2C08B0()
{
  return 0LL;
}

__int64 sub_2BD51C()
{
  return 0LL;
}

__int64 sub_2BBD90()
{
  return 0LL;
}

__int64 sub_2B6B40()
{
  return 0LL;
}


void *TBDATA_THREAD(void *) {
auto UE4 = Tools::GetBaseAddress("libTBlueData.so");
while (!UE4) {
UE4 = Tools::GetBaseAddress("libTBlueData.so");
sleep(1);
}
    LOGI(OBFUSCATE("LOAD BY @NIKON_OWNER"));
do {
sleep(1);
} while (!isLibraryLoaded("libTBlueData.so"));
#if defined(__aarch64__)
HOOK_LIB("libTBlueData.so","0x9AD94",hsub_9AD94,osub_9AD94); //Flag fix
HOOK_LIB_NO_ORIG("libTBlueData.so","0x2BFF7C",sub_2BFF7C);
HOOK_LIB_NO_ORIG("libTBlueData.so","0x2C08B0",sub_2C08B0);
HOOK_LIB_NO_ORIG("libTBlueData.so","0x2BD51C",sub_2BD51C);
HOOK_LIB_NO_ORIG("libTBlueData.so","0x2BBD90",sub_2BBD90);
HOOK_LIB_NO_ORIG("libTBlueData.so","0x2B6B40",sub_2B6B40);
#endif
return NULL;
}


void *HDM_thread(void *) {
    LOGI(OBFUSCATE("LOAD BY @NIKON_MOD"));
    do {
    sleep(1);
    } while (!isLibraryLoaded("libhdmpve.so"));
    
    #if defined(__aarch64__)    
/////////    FLAG DELAY + REPORT HELPER   /////////
MemoryPatch::createWithHex("libhdmpve.so", 0x12363C, "00 00 80 D2 C0 03 5F D6").Modify();
PATCH_LIB("libhdmpve.so","0x3A13B4","00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libhdmpve.so","0x1A95FC","00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libhdmpve.so","0x3DFC40","00 00 80 D2 C0 03 5F D6");
PATCH_LIB("libhdmpve.so","0x40A474","00 00 80 D2 C0 03 5F D6");
#endif
return NULL;
}

__attribute__((constructor))
void lib_main() {

    pthread_t ptid;
    
    pthread_create(&ptid, NULL, ANOGS_THREAD, NULL);
    pthread_create(&ptid, NULL, TBDATA_THREAD, NULL);
    pthread_create(&ptid, NULL, UE4_THREAD, NULL);
   pthread_create(&ptid, NULL, HDM_thread, NULL);
       
}
